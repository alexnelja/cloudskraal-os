# Design System Specification: The Agricultural Intelligence Framework

## 1. Overview & Creative North Star: "The Digital Agronomist"
This design system rejects the "clunky enterprise" aesthetic in favor of **The Digital Agronomist**. Our North Star is a high-density, editorial-grade interface that balances the rugged utility of a Bloomberg Terminal with the serene, systematic clarity of Notion. 

We move beyond standard SaaS patterns by treating data as a living organism. The UI is not a collection of boxes; it is a series of intentional, layered surfaces that mimic the stratification of soil and the precision of modern irrigation. We achieve "Premium Technicality" through:
- **Intentional Asymmetry:** Breaking the grid for key insights to draw the eye.
- **Tonal Depth:** Replacing harsh lines with sophisticated color shifts.
- **Editorial Typography:** Using scale to create a clear narrative in data-heavy views.

---

## 2. Colors: Tonal Stratification
Our palette is rooted in the earth but refined by technology. We use Material Design token logic to ensure accessibility while maintaining a bespoke, "high-end" mood.

### The Palette
- **Primary (Rooibos):** `#005d42` (Emerald-800 transition) – The color of authority and growth.
- **Secondary (Wine):** `#712ae2` – Used for biological insights and livestock health.
- **Tertiary (Sheep):** `#7d4200` – Used for harvest cycles and heavy machinery.
- **Neutral (Buchu/Stone):** `#f9f9f8` (Surface) and `#1a1c1c` (On-Surface).

### The "No-Line" Rule
**Borders are a failure of hierarchy.** Designers are prohibited from using 1px solid lines to separate major sections. Instead, use background shifts:
- Place a `surface-container-low` (`#f3f4f3`) sidebar against a `surface` (`#f9f9f8`) canvas.
- Define content zones through the `surface-container` tiers rather than strokes.

### Glass & Gradient
To prevent the UI from feeling "flat" or "cheap," use **Glassmorphism** for floating overlays (e.g., Modals, Tooltips) with a `backdrop-blur` of 12px. Main CTAs should utilize a subtle linear gradient from `primary` (`#005d42`) to `primary_container` (`#047857`) at a 145-degree angle to add a "gem-like" depth.

---

## 3. Typography: The Editorial Scale
We use a clean System Font Stack (Inter/San Francisco) to ensure zero-latency rendering. The hierarchy is designed to make dense data feel scannable and sophisticated.

- **Display (Large Data Points):** `display-md` (2.75rem) / Semibold. Reserved for critical yield numbers or total acreage.
- **Headlines:** `headline-sm` (1.5rem) / Semibold. Used for section starts.
- **Body:** `body-md` (0.875rem) / Regular. This is our workhorse. It ensures high data density without sacrificing legibility.
- **Labels:** `label-sm` (0.6875rem) / Medium / All-caps with 0.05em tracking. Used for table headers and metadata.

---

## 4. Elevation & Depth: Tonal Layering
In this system, elevation is not a shadow; it is a **layer**.

### The Layering Principle
Hierarchy is achieved by "stacking" surface tokens:
1. **Base Layer:** `surface` (`#f9f9f8`)
2. **Structural Sections:** `surface-container-low` (`#f3f4f3`)
3. **Interactive Cards:** `surface-container-lowest` (`#ffffff`) — this creates a natural "lift" against the greyish base.

### Shadows & Ghost Borders
- **Ambient Shadows:** Only used for floating elements (e.g., Pickers). Use a 24px blur, 0px offset, at 4% opacity using the `on-surface` color.
- **The Ghost Border:** For high-density tables where separation is critical, use the `outline-variant` (`#bdc9c1`) at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Precision Utilitarianism

### Buttons (Rounded-lg: 1rem)
- **Primary:** Gradient fill (`primary` to `primary_container`), white text. High-gloss finish.
- **Secondary:** `surface-container-highest` fill with `on-surface` text. No border.
- **Tertiary:** Transparent background, `primary` text. Use for low-emphasis actions.

### Cards (Rounded-xl: 1.5rem)
Cards must never use dividers. Use `spacing-5` (1.1rem) to create clear groupings of data. Use `surface-container-lowest` for the card body to make it "pop" from the `surface` background.

### Input Fields
Inputs use `surface-container-low` as a base with a `ghost-border` that transitions to a 2px `primary` bottom-border on focus. This mimics the "Bloomberg" terminal's professional input style.

### Badges & Pills (Rounded-full)
Used for status (e.g., "In-Transit," "Harvested"). Use the Enterprise Palette colors (Wine, Buchu, Sheep) at 15% opacity with high-contrast text for a premium, "soft-tag" look.

---

## 6. Do's and Don'ts

### Do
- **Do** lean into data density. Farmers need information at a glance; don't be afraid of small, well-organized text.
- **Do** use Lucide icons in a `thin` (1.5px) stroke weight to maintain an airy, high-end feel.
- **Do** use `spacing-4` (0.9rem) for internal card padding to maintain the "Notion" compactness.

### Don't
- **Don't** use black (`#000000`) for text. Always use `Stone-800` (`#1c1917`) to keep the interface feeling organic.
- **Don't** use standard "Drop Shadows" on cards. Rely on the white-on-grey tonal shift.
- **Don't** use vertical dividers in tables. Use subtle row striping with `surface-container-low` instead.