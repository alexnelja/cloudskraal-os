# Cloudskraal Home

<aside>
💡 **Notion Tip:** Use this template to organize important information for your team. Add owners, verification, and tags to pages to keep them up to date. Just replace this sample content with your own

</aside>

---

[Getting Started](https://www.notion.so/Getting-Started-21401ea49c10806eaeaff19bddc444b9?pvs=21)

---

[Untitled](Cloudskraal%20Home/Untitled%2028401ea49c1080dc814de5e2486658fd.csv)

---

## Team

---

[Benefits Policies](https://www.notion.so/Benefits-Policies-21401ea49c1080ca8466cc19256e674e?pvs=21)

[Expense Policy](https://www.notion.so/Expense-Policy-21401ea49c108082ada3fb2e7a10bbaa?pvs=21)

[Contract Workers](https://www.notion.so/Contract-Workers-28401ea49c10808e9965d1a407fd8f3b?pvs=21)

## Policies

---

[Systems](https://www.notion.so/Systems-21401ea49c108068b1a3ef8fc1a116f0?pvs=21)

[Mission, Vision, Values](https://www.notion.so/Mission-Vision-Values-21401ea49c108086b311eb0c486abdb5?pvs=21)

[ Morale Events](https://www.notion.so/Morale-Events-21401ea49c1080e5b67ac7fac6c947e4?pvs=21)

[Additional Routines](https://www.notion.so/Additional-Routines-21401ea49c10802b9468f1eb14156fa6?pvs=21)

[Cloudskraal History](https://www.notion.so/Cloudskraal-History-21401ea49c1080b095f4fe5961f71168?pvs=21)

## Work Management

---

[Tasks Tracker](https://www.notion.so/21401ea49c10809c9fdfca81b112cb59?pvs=21)

[Cloudskraal Calendar](https://www.notion.so/28401ea49c1080f2b312f97c68adeb59?pvs=21)

## Master Lists

---

[Team Members](https://www.notion.so/21401ea49c1080de80b9c924b71858af?pvs=21)

[Departments](https://www.notion.so/21401ea49c1080f7816ae0ca07fbdf72?pvs=21)

[Farms](https://www.notion.so/21401ea49c10805db8ceed93e824f31f?pvs=21)

[Goals](https://www.notion.so/21401ea49c1080b4aa4afbf30dd88cde?pvs=21)

[Untitled](Cloudskraal%20Home/Untitled%2021401ea49c10808d9041cca8351c4bfc.csv)