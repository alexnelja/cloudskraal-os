# Alex’s To-Do List

### Problems with As-Is

- Driving around to check on the various tasks that are happening on the farm
    - Costs time and fuel from management
    - Minimize to focus on crucial processes
    - Radios could partially improve this process
        - 
        
        [Motorola Two-Way Radios](https://www.walkietalkiesa.co.za/collections/motorola-two-way-radios)
        
    - 
    
    [EziTrack - Vehicle, Asset and Personal DIY Tracking Systems](https://ezitrack.co.za/)
    
- Workers do not show in their best condition
    - Often arrive drunk to work
    - Often do not come to work
    - Stay away for health reasons but don’t bring a letter
    - The good workers have lower morale, because their positive effort is not rewarded and bad behaviour is not punished
    - The system to track the leave days are not connected and do not automatically flag poor employees, need a system to track and manage
- Fuel is not being tracked
    - Theft is possible
    - no tracking of the per hactare costs of the products as the inputs for the fields are not being tracked
    - If a specific tractor is using massive amounts of fuel and oil, there is possibly a problem with the tractor and it can be flagged
    - Oil and Fuel tracking, can be a trigger for a maintenance session
- Input for the fields are not being tracked
    - We do not know when and what is being distributed into the soil
    - This can aid us in determining what is the cost per hecatre, specific to each field. As this decreases we can make an algorithmic rule that determines when the old rooibos needs to go through a fresh cycle
- Work done is not being tracked
    - Workers can start with a job and then stop, but don’t report back that the task is completed and check marked
    - An option is to have them take a picture of the job on their phone when they are done
- There is no maintenance log or schedule, so vehicles are not regularly checked, but are worked when they break
    - Preventative maintenance is usually cheaper thatn reparative maintenance
    - Breakdown time often leads to delays and often to less than optimal conditions for planting and spraying
- Many times the batteries for the tractors are flat and they need to borrow batteries from other tractors
    - This is also a reason for an increased lead time for many of the tractors
- Workers without the proper training are operating forklifts and tractors
    - This leads to damage of the very expensive equipment
    - More breakdown, more delay
    - Also a OHS safety hazard
- Workers lack the motivation to work
    - They lack the proper incentive and disincentive to work for, they don’t have a carrot or a wip
- We are not currently planting enough tea to fully utilise the plant that we just bought
    - The new facility at Garsland increases our production capacity from 200 tonnes per year, to 600 tonnes per year.
    - We need to find or lease additional lands to fill up the facility
    - The increased economies of scale will make it easier
- No way to see where the sheep herd currently is, so no tracking of the sheep
- No Identification and tracking of genetics between generations
- No way to know how much tea was produced from a specific field
- Lack of good loose workers to cut tea fast enough
    - This leads to a longer cutting season, which makes us dry the tea in the wetter season.
    - The wetter the drying period the lower the quality of the tea that is produced
    - The ideal would be to have temporary teams, each with a foreman
        - That invoices us, saving much admin costs and also makes it easier for us to manage larger and multiple teams at a time
- Japie cannot leave the farm for long, as there is no on that can keep an eye and monitor what is going on
    - Without the break this will cause mental drain, which means a less than optimal strategic advice
- Frances can not leave the farm for long
    - As she does the weekly payslips
    - The payslip system is currently on a desktop only and not on the cloud
    - My personal lack of understanding how the system works also is a problem.
- The internet intermittently goes off, making it hard to use any full cloud solutions
    - The IP cameras cannot broadcast to our phones for monitoring, if there is no internet
- Workers do not do a pre-check on vehicles before driving them
    - Add a pre-check diagram to the tractors
    - Also ad specific instructions to the implements, like the baler, the combine harvester,
- The batteries of tractors that are standing still run dead
    - Buy a R250 trickle charger, when tractors are parked, they are connected to a trickle charger.

So I have a list of systems that I would like to work on

- Team Management
    - Daily Huddle
    - Weekly Goals Board
    - Monthly One-on-one’s
    - 5 x Radio’s , All modern tractors and managers have radios with them.
        - A Broadcast tower will assist in increasing the range
- Task Management
    - Implement a task management system either using field margin or with notion
    - Alternatively a physical Kanban Board would also help
- Field Management
    - Tracking of all input in the fields, which pesticide, for which field, what amount, using which tractor
    - Capture the output from each field.