# Version 1 - Draft Proposal

## **📑 Draft Proposition for Kromvlei**

**To:** Current Owner of Kromvlei

**From:** Cloudskraal Boerderye (represented by Alex Nel)

**Subject:** Strategic Partnership / Acquisition Proposal – Kromvlei Farm

---

### **1. Introduction**

Cloudskraal is looking to responsibly expand its rooibos operations in Nieuwoudtville. Kromvlei represents a unique opportunity to secure ~100 hectares of productive land that aligns perfectly with our long-term vision of sustainable rooibos farming and value creation.

---

### **2. Strategic Fit**

- **Production Expansion:** The addition of Kromvlei would increase Cloudskraal’s production capacity by approximately 100 tonnes annually.
- **Economies of Scale:** Larger volumes enable more efficient harvesting, transport, and processing, strengthening profitability even at modest margins (≈R2.50/kg net).
- **Long-term Growth:** With Kromvlei integrated, Cloudskraal will be in a strong position to expand into export markets and build resilience against price volatility.

---

### **3. Financial Structure (Proposal)**

We aim to propose a structure that is sustainable for Cloudskraal while fair to you as the seller. Several options are available:

**Option A: Phased Purchase**

- Deposit of 10–20% upfront.
- Balance structured over 4–6 years with annual interest-only payments.
- Balloon payment at the end of the term.

**Option B: Rooibos-Linked Payment**

- Annual payments in kind (rooibos tonnage equivalent to agreed Rand value) for 4–5 years.
- Final cash settlement thereafter.

**Option C: Lease-to-Own**

- Lease agreement with fixed annual payments (cash or rooibos equivalent).
- Transfer of ownership upon completion of lease term.

---

### **4. Mutual Benefits**

- **For the Owner of Kromvlei:**
    - A structured, reliable exit strategy with annual income.
    - Flexibility to choose a financial arrangement (cash, produce, or hybrid) that best fits your needs.
- **For Cloudskraal:**
    - Secures additional land to scale operations.
    - Ensures sustainable growth while managing financial risk.
    - Strengthens the long-term viability of the farm and the local industry.