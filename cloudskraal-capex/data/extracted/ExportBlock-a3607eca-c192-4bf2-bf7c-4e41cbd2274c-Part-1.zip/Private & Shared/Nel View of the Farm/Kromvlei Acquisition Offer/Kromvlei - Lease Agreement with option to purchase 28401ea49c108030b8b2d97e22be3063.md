# Kromvlei - Lease Agreement with option to purchase V1

# **LEASE AGREEMENT (FIELDS ONLY) WITH OPTION TO PURCHASE**

**Between:**

1. **Lessor**
    
    **Hugo van Niekerk**
    
    Identity/Registration No: ____________________
    
    (“**Lessor**”)
    
2. **Lessee**
    
    **Cloudskraal Boerderye**
    
    Registration/ID No: ____________________
    
    Email: **cloudskraal@hantam.co.za**
    
    Duly represented by **Jacobus Adriaan Louw Nel**
    
    (“**Lessee**”)
    

---

## **A. PROPERTY DESCRIPTION (FIELDS ONLY)**

The Lessor is the registered owner of the following immovable properties. The parties agree that **only the agricultural fields/land portions** are leased, excluding all buildings, worker housing, yards, and store areas as identified between the parties:

- **Portion 1 of the farm Cloudskraal No. 1/644**, situated in the **Hantam Municipality**, Division **Calvinia**, Northern Cape, measuring **391.02 hectares**.
- **Portion 2 of the farm Cloudskraal No. 1/644**, situated in the **Hantam Municipality**, Division **Calvinia**, Northern Cape, measuring **267.56 hectares**.

(Collectively referred to as the “**Property**” or “**Fields**”.)

---

## **1. TERM**

1.1 This lease commences on **[Effective Date: ___ / ___ / 20__]** and endures for **6 (six) years**, subject to the purchase option in Clause 3. *(No early exit right applies.)*

---

## **2. RENT – LINKED TO ROOIBOS PRODUCTION (FIELDS ONLY)**

2.1 Annual rent is **variable** and linked to the Lessee’s **actual gross dry rooibos tea tonnage** produced **on the Fields** and harvested in the relevant year.

2.2 **Formula:**

**Annual Rent = max(Floor; Actual Tonnes × Rate per Tonne), capped at an Annual Cap.**

- **Floor:** **R150,000** per annum.
- **Rate per tonne (gross dry):** **R3,500 / tonne**.
- **Annual Cap:** **R400,000** per annum.

2.3 **Payment & verification:** Rent is payable **in cash** by **[due date each year]**, based on audited weighbridge/processing records. By written agreement, a portion may be delivered **in kind (rooibos)** at an agreed price basis.

2.4 **Standards:** Lessee will comply with **SAGAP** (South African Good Agricultural Practices).

---

## **3. OPTION TO PURCHASE (R10,000,000)**

3.1 The Lessor grants the Lessee an **irrevocable option** to purchase the **Fields** for **R10,000,000 (ten million rand)**, **indexed by CPI** from the Effective Date to the Exercise Date (not market-linked).

3.2 **Exercise windows/dates:** The option may be exercised in writing at the end of **Year 3**, **Year 5**, **Year 7**, or **Year 10**, provided at least **90 (ninety) days’** prior written notice is given.

3.3 **Rent credits:** **50% of all rent paid** under this lease **will be credited** against the option price if the option is exercised.

3.4 **Capital improvements:** Approved fixed capital improvements made by the Lessee to the Fields (irrigation, fencing, soil improvement, etc.) **reduce the net purchase price rand-for-rand** on exercise, or, if the option is not exercised, are **reimbursed at fair residual value** by the Lessor.

3.5 **Completion:** Upon exercise, transfer is to be completed within **120 days**, with standard warranties of title, risk passing on registration, and normal apportionment of costs per law.

---

## **4. RIGHT OF FIRST REFUSAL (ROFR)**

4.1 If the Lessor receives a **bona fide written third-party offer** to purchase the Fields (or the larger property including the Fields), the Lessor will disclose the **full terms** in writing to the Lessee.

4.2 The Lessee has **30 (thirty) days** to **match** such offer. If not matched, the Lessor may proceed with that purchaser **on materially the same terms** within **120 days**; any improved terms **re-trigger** the ROFR.

4.3 The ROFR applies **in addition** to the Lessee’s purchase option in Clause 3.

---

## **5. USE**

5.1 The Fields are to be used for **rooibos tea farming**; the Lessee may keep **livestock (sheep/cattle)** and plant **annual crops** (wheat, oats, lupins), observing conservation, water, and soil-health regulations.

5.2 No residential rights for workers/occupiers are created.

---

## **6. SUBLETTING AND CESSION**

No subletting, cession, pledge, delegation, or transfer without the Lessor’s **prior written consent**.

---

## **7. RATES, ELECTRICITY & MAINTENANCE**

7.1 **Lessor:** property rates/charges.

7.2 **Electricity:** billed by Lessor to Lessee for usage.

7.3 **Lessee:** maintenance of Fields, fencing, plantings; **buildings remain the Lessor’s responsibility**.

---

## **8. FIRE & ENVIRONMENT**

Lessee to be a member of the applicable **Fire Protection Association**; comply with **National Water Act**, **Biodiversity Act** (alien/invasive control), erosion and wildfire rules; keep Fields free of noxious weeds.

---

## **9. INSURANCE & RISK**

Lessee not to prejudice insurance; any premium increase caused by Lessee is for Lessee’s account. Goods on the Fields are at Lessee’s risk.

---

## **10. “AS IS”**

Fields are leased **as is** (voetstoots); no warranties as to soil characteristics or suitability.

---

## **11. INSPECTION**

Lessor may inspect the Fields at reasonable times or appoint an agent to do so.

---

## **12. IMPROVEMENTS**

No attachments/capital works without prior written consent; all required approvals/plans to be obtained and complied with.

---

## **13. BREACH**

13.1 On non-payment/material breach not remedied within **15 days** of written notice, the Lessor may cancel and claim eviction.

13.2 While in occupation, rent remains payable notwithstanding disputes (except where directly caused by Lessor’s default).

---

## **14. HAND-BACK ON EXPIRY**

On expiry/termination the Lessee returns the Fields in **the same condition** (fair wear and tear excepted). Approved improvements are transferred or compensated per Clause 3.4.

---

## **15. SALE/LETTING NOTICES**

Lessor may place reasonable “for sale/to let” notices; Lessee to allow reasonable access to prospective purchasers/tenants.

---

## **16. TRANSFER OF OWNERSHIP**

On transfer, the purchaser/successor **ipso jure** becomes Lessor and is bound by this agreement.

---

## **17. DOMICILIUM (NOTICES)**

- **Lessee:** **Cloudskraal Boerderye**, Address: _______________________; Email: **cloudskraal@hantam.co.za**
- **Lessor:** **Hugo van Niekerk**, Address: ____________________________; Email: ____________________________

---

## **18. JURISDICTION & COSTS**

Parties consent to the jurisdiction of the **Magistrates’ Court** (without waiving the right to approach a higher court). Legal costs on an **attorney-and-client** scale where applicable.

---

## **19. ENTIRE AGREEMENT & VARIATIONS**

This is the **entire agreement**. No amendment/waiver is valid unless **in writing** and signed by both parties.

---

## **20. FORCE MAJEURE**

Standard force-majeure events (fire, flood, war, state action, etc.) suspend performance as specified.

---

## **21. SEVERABILITY**

Invalid/unenforceable provisions do not affect the remainder.

---

## **22. CONFIDENTIALITY**

The agreement is **confidential**, save for disclosure to professionals/financiers/authorities or corporate governance bodies, or where disclosure is required to implement the agreement.

---

## **23. DISPUTE RESOLUTION & ARBITRATION**

Disputes are first negotiated; if unresolved within **10 days**, they proceed to **arbitration** in the **Western Cape** (e.g., Citrusdal) under applicable arbitration law. The arbitrator’s award is **final and binding**. Urgent interdicts remain available in a competent court.

---

**SIGNED at** ____________________ on this _____ day of ______________ 20____.

**AS WITNESSES:**                         **LESSOR (Hugo van Niekerk):**

1. 
    
    ---
    
2. ___________________________ Name: ________________________

**AS WITNESSES:**                         **LESSEE (Cloudskraal Boerderye):**

1. 
    
    ---
    
2. ___________________________ Name: ________________________

---