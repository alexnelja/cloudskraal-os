# Kromvlei voor wingerd

Hectares (ha): 18.918
Expected Yield (t/ha): 160
Our expected yield: 200
Expected Total Yield (t): 3026.88
Our expected Yield (t) (1): 3783.6
Formula: 105940.8
Formula (1): 132426