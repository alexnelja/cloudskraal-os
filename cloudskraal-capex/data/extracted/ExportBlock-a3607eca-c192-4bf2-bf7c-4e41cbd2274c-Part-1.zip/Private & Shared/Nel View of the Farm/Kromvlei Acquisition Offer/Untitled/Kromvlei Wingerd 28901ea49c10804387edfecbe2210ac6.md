# Kromvlei Wingerd

Hectares (ha): 14.318
Expected Yield (t/ha): 0
Our expected yield: 0
Expected Total Yield (t): 0
Our expected Yield (t) (1): 0
Formula: 0
Formula (1): 0