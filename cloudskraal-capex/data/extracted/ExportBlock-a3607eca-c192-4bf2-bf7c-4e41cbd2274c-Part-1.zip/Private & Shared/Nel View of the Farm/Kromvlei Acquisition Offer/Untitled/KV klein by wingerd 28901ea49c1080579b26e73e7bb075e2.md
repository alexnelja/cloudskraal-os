# KV klein by wingerd

Hectares (ha): 7.3
Expected Yield (t/ha): 180
Our expected yield: 250
Expected Total Yield (t): 1314
Our expected Yield (t) (1): 1825
Formula: 45990
Formula (1): 63875