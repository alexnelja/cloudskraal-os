# Kromvlei agter Wingerd

Hectares (ha): 20.318
Expected Yield (t/ha): 300
Our expected yield: 450
Expected Total Yield (t): 6095.4
Our expected Yield (t) (1): 9143.1
Formula: 213339
Formula (1): 320008.5