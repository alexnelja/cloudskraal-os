# KromVlei hoek hoek

Hectares (ha): 5.346
Expected Yield (t/ha): 180
Our expected yield: 300
Expected Total Yield (t): 962.28
Our expected Yield (t) (1): 1603.8
Formula: 33679.8
Formula (1): 56133