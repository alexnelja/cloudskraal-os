# Contract Workers for January

Assigned To: Frances Nel
Date: November 13, 2025
Text: Need to Find Boss Boys

- Boss Boys
    - Natasha
    - Kabamba
    - Frikkie

- Ricus Goldfaarb
- Clanwilliam Teams